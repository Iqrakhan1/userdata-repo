package user.userdata.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

// uses Lombok annotations to generate getters, setters, and constructors for the class.
public class UserData {
    String email;          //a string representing the email of the user
    String firstName;     //a string representing the firstName of the user
    String lastName;     //a string representing the lastName of the user
    String gender;      //a string representing the gender of the user
    int age;           //a string representing the age of the user

}
