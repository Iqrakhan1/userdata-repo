package user.userdata.service;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import user.userdata.model.UserData;

@Service
@Component
public class userService {
    ArrayList<UserData> userList= new ArrayList<>();
    
   // saveUser which adds a UserData object to the userList array list and returns the user's first name as a string.
    
    public String saveUser(UserData user){
        userList.add(user);
        
    System.out.println(user.getEmail());
    System.out.println("user saved successfully");
    System.out.println(user.getFirstName());
    return user.getFirstName();
       

    }
    //getUserList which returns the entire userList array list.
    
    public ArrayList<UserData> getUserList(){
        return userList;
    }
   // getUserByEmail which takes in an email string, searches through the userList array list for a matching UserData object,
    //and returns it if found. If no match is found, it returns null.
    
    public UserData getUserByEmail(String email) {
        for (UserData tempuser : userList) {
            if (tempuser.getEmail().equals(email)) {
                return tempuser;
            }
        }
        return null;
    }
    
    
}
