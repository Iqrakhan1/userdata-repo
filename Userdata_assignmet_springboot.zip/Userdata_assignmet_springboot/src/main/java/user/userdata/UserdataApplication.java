package user.userdata;


//This is the main class of a Spring Boot application that initializes the Spring framework and enables auto-configuration and component scanning.

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserdataApplication.class, args);
	}

}
